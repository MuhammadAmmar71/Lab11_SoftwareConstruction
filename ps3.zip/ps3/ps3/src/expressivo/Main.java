package expressivo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        Optional<String> currentExpression = Optional.empty();

        while (true) {
            System.out.print("> ");
            String input = in.readLine();

            if (input.isEmpty()) return;

            try {
                if (input.startsWith("!simplify")) {
                    if (currentExpression.isEmpty()) {
                        System.out.println("No expression to simplify!");
                        continue;
                    }
                    Map<String, Double> environment = parseEnvironment(input.substring(9).trim());
                    String result = Commands.simplify(currentExpression.get(), environment);
                    System.out.println(result);
                } else {
                    Expression expr = Expression.parse(input);
                    currentExpression = Optional.of(expr.toString());
                    System.out.println(expr.toString());
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static Map<String, Double> parseEnvironment(String input) {
        Map<String, Double> environment = new HashMap<>();
        if (!input.isEmpty()) {
            String[] assignments = input.split(" ");
            for (String assignment : assignments) {
                String[] parts = assignment.split("=");
                if (parts.length == 2) {
                    environment.put(parts[0], Double.parseDouble(parts[1]));
                }
            }
        }
        return environment;
    }
}
