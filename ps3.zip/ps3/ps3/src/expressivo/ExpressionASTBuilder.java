package expressivo;

import expressivo.parser.ExpressionBaseVisitor;
import expressivo.parser.ExpressionParser;

public class ExpressionASTBuilder extends ExpressionBaseVisitor<Expression> {
    @Override
    public Expression visitSum(ExpressionParser.SumContext ctx) {
        Expression left = visit(ctx.expression(0));
        Expression right = visit(ctx.expression(1));
        return new BinaryOperation("+", left, right);
    }

    @Override
    public Expression visitProduct(ExpressionParser.ProductContext ctx) {
        Expression left = visit(ctx.term(0));
        Expression right = visit(ctx.term(1));
        return new BinaryOperation("*", left, right);
    }

    @Override
    public Expression visitNumber(ExpressionParser.NumberContext ctx) {
        double value = Double.parseDouble(ctx.NUMBER().getText());
        return new Literal(value);
    }

    @Override
    public Expression visitVariable(ExpressionParser.VariableContext ctx) {
        return new Variable(ctx.VARIABLE().getText());
    }

    @Override
    public Expression visitGroupedExpression(ExpressionParser.GroupedExpressionContext ctx) {
        return visit(ctx.expression());
    }
}
