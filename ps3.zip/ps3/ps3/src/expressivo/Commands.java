package expressivo;

import java.util.Map;

public class Commands {
    public static String differentiate(String expression, String variable) {
        Expression parsedExpression = Expression.parse(expression);
        Expression differentiatedExpression = parsedExpression.differentiate(variable);
        return differentiatedExpression.toString();
    }

    public static String simplify(String expression, Map<String, Double> environment) {
        Expression parsedExpression = Expression.parse(expression);
        Expression simplifiedExpression = parsedExpression.simplify(environment);
        return simplifiedExpression.toString();
    }
}
