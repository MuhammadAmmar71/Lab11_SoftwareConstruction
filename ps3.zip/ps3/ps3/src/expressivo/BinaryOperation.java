package expressivo;

import java.util.Map;

/**
 * Represents a binary operation (+ or *) in an expression.
 * Immutable and recursive.
 */
public class BinaryOperation implements Expression {
    private final String operator;
    private final Expression left;
    private final Expression right;

    public BinaryOperation(String operator, Expression left, Expression right) {
        this.operator = operator;
        this.left = left;
        this.right = right;
        checkRep();
    }

    private void checkRep() {
        assert operator.equals("+") || operator.equals("*");
        assert left != null && right != null;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " " + operator + " " + right.toString() + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof BinaryOperation)) return false;
        BinaryOperation that = (BinaryOperation) obj;
        return this.operator.equals(that.operator)
                && this.left.equals(that.left)
                && this.right.equals(that.right);
    }

    @Override
    public int hashCode() {
        return operator.hashCode() + 31 * left.hashCode() + 31 * right.hashCode();
    }

    @Override
    public Expression differentiate(String variable) {
        if (operator.equals("+")) {
            return new BinaryOperation("+", left.differentiate(variable), right.differentiate(variable));
        } else if (operator.equals("*")) {
            Expression leftDerivative = new BinaryOperation("*", left.differentiate(variable), right);
            Expression rightDerivative = new BinaryOperation("*", left, right.differentiate(variable));
            return new BinaryOperation("+", leftDerivative, rightDerivative);
        }
        throw new UnsupportedOperationException("Unknown operator: " + operator);
    }

    @Override
    public Expression simplify(Map<String, Double> environment) {
        Expression simplifiedLeft = left.simplify(environment);
        Expression simplifiedRight = right.simplify(environment);

        if (simplifiedLeft instanceof Literal && simplifiedRight instanceof Literal) {
            double leftValue = ((Literal) simplifiedLeft).value;
            double rightValue = ((Literal) simplifiedRight).value;
            return operator.equals("+") ? new Literal(leftValue + rightValue) : new Literal(leftValue * rightValue);
        }

        if (operator.equals("+")) {
            if (simplifiedLeft instanceof Literal && ((Literal) simplifiedLeft).value == 0) return simplifiedRight;
            if (simplifiedRight instanceof Literal && ((Literal) simplifiedRight).value == 0) return simplifiedLeft;
        }

        if (operator.equals("*")) {
            if (simplifiedLeft instanceof Literal && ((Literal) simplifiedLeft).value == 0) return new Literal(0);
            if (simplifiedRight instanceof Literal && ((Literal) simplifiedRight).value == 0) return new Literal(0);
            if (simplifiedLeft instanceof Literal && ((Literal) simplifiedLeft).value == 1) return simplifiedRight;
            if (simplifiedRight instanceof Literal && ((Literal) simplifiedRight).value == 1) return simplifiedLeft;
        }

        return new BinaryOperation(operator, simplifiedLeft, simplifiedRight);
    }
}
