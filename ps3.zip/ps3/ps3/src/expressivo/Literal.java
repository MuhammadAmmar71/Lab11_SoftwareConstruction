package expressivo;

/**
 * Represents a literal constant (number) in an expression.
 * Immutable.
 */
public class Literal implements Expression {
    private final double value; // Keep field private for encapsulation

    public Literal(double value) {
        this.value = value;
    }

    public double getValue() { // Add a public getter method
        return value;
    }

    @Override
    public String toString() {
        return Double.toString(value);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Literal)) return false;
        Literal that = (Literal) obj;
        return Double.compare(this.value, that.value) == 0;
    }

    @Override
    public int hashCode() {
        return Double.hashCode(value);
    }

    @Override
    public Expression differentiate(String variable) {
        return new Literal(0); // The derivative of a constant is 0
    }

    @Override
    public Expression simplify(Map<String, Double> environment) {
        return this; // A literal is already simplified
    }
}
