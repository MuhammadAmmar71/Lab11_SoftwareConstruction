package expressivo;

import java.util.Map;

public interface Expression {
    static Expression parse(String input) {
        try {
            CharStream charStream = CharStreams.fromString(input);
            ExpressionLexer lexer = new ExpressionLexer(charStream);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            ExpressionParser parser = new ExpressionParser(tokens);
            parser.reportErrorsAsExceptions();
            ExpressionParser.RootContext tree = parser.root();
            ExpressionASTBuilder astBuilder = new ExpressionASTBuilder();
            return astBuilder.visit(tree);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid expression: " + input, e);
        }
    }

    @Override
    String toString();

    @Override
    boolean equals(Object thatObject);

    @Override
    int hashCode();

    Expression differentiate(String variable);

    Expression simplify(Map<String, Double> environment);
}
