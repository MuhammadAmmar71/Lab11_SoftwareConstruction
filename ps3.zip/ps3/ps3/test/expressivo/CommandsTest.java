/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package expressivo;

import static org.junit.Assert.*;

import java.util.Map; // Ensure Map is imported

import org.junit.Test;

/**
 * Tests for the static methods of Commands.
 */
public class CommandsTest {

    // Testing strategy
    //   TODO
    
    @Test(expected=AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }
    
    // TODO tests for Commands.differentiate() and Commands.simplify()
    @Test
    public void testDifferentiateSimple() {
        assertEquals("1.0", Commands.differentiate("x", "x"));
        assertEquals("0.0", Commands.differentiate("y", "x"));
    }

    @Test
    public void testDifferentiateSum() {
        assertEquals("(1.0 + 0.0)", Commands.differentiate("x + 3", "x"));
    }

    @Test
    public void testDifferentiateProduct() {
        assertEquals("((1.0 * x) + (x * 1.0))", Commands.differentiate("x * x", "x"));
    }
    
    @Test
    public void testSimplifyCommands() {
        assertEquals("5.0", Commands.simplify("x", Map.of("x", 5.0)));
        assertEquals("(x + 3.0)", Commands.simplify("x + 3", Map.of()));
        assertEquals("8.0", Commands.simplify("x + 3", Map.of("x", 5.0)));
    }

}
