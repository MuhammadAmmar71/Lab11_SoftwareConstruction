package expressivo;

import static org.junit.Assert.*;
import java.util.Map; // Ensure the Map interface is imported
import org.junit.Test;

public class ExpressionTest {

    @Test
    public void testLiteralToString() {
        Expression literal = new Literal(3.0);
        assertEquals("3.0", literal.toString());
    }

    @Test
    public void testVariableToString() {
        Expression variable = new Variable("x");
        assertEquals("x", variable.toString());
    }

    @Test
    public void testBinaryOperationToString() {
        Expression expr = new BinaryOperation("+", new Variable("x"), new Literal(3));
        assertEquals("(x + 3.0)", expr.toString());
    }

    @Test
    public void testValidExpressions() {
        assertEquals("3.0", Expression.parse("3").toString());
        assertEquals("(x + 3.0)", Expression.parse("x + 3").toString());
        assertEquals("(x * (3.0 + 2.0))", Expression.parse("x * (3 + 2)").toString());
        assertEquals("((x * x) + (y * y))", Expression.parse("x * x + y * y").toString());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidExpression_MissingOperator() {
        Expression.parse("3 x");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidExpression_UnmatchedParentheses() {
        Expression.parse("(3 + x");
    }
    
    @Test
    public void testDifferentiateLiteral() {
        Expression literal = new Literal(5);
        assertEquals("0.0", literal.differentiate("x").toString());
    }

    @Test
    public void testDifferentiateVariable() {
        Expression variable = new Variable("x");
        assertEquals("1.0", variable.differentiate("x").toString());
        assertEquals("0.0", variable.differentiate("y").toString());
    }

    @Test
    public void testDifferentiateSum() {
        Expression expr = new BinaryOperation("+", new Variable("x"), new Literal(3));
        assertEquals("(1.0 + 0.0)", expr.differentiate("x").toString());
    }

    @Test
    public void testDifferentiateProduct() {
        Expression expr = new BinaryOperation("*", new Variable("x"), new Literal(3));
        assertEquals("((1.0 * 3.0) + (x * 0.0))", expr.differentiate("x").toString());
    }

    @Test
    public void testNestedDifferentiation() {
        Expression expr = new BinaryOperation("*", new Variable("x"), new Variable("x"));
        assertEquals("((1.0 * x) + (x * 1.0))", expr.differentiate("x").toString());
    }
    
    @Test
    public void testSimplifyLiteral() {
        Expression expr = new Literal(5);
        assertEquals("5.0", expr.simplify(Map.of()).toString());
    }

    @Test
    public void testSimplifyVariable() {
        Expression expr = new Variable("x");
        assertEquals("5.0", expr.simplify(Map.of("x", 5.0)).toString());
        assertEquals("x", expr.simplify(Map.of()).toString());
    }

    @Test
    public void testSimplifySum() {
        Expression expr = new BinaryOperation("+", new Variable("x"), new Literal(3));
        assertEquals("8.0", expr.simplify(Map.of("x", 5.0)).toString());
    }

    @Test
    public void testSimplifyProduct() {
        Expression expr = new BinaryOperation("*", new Variable("x"), new Literal(0));
        assertEquals("0.0", expr.simplify(Map.of("x", 5.0)).toString());
    }
}
